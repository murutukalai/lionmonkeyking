// Route - Web - Task

use axum::{extract::Path, response::Html, Extension};
use sailfish::TemplateOnce;

use super::{WebAuthUser, WebResult};
use crate::{
    api::{
        all_task::{self, TaskAllItem, TaskSearchInput},
        employee::{self, EmployeeInfo},
        task::{self, Task, TaskGroup},
        task_comment::{self, TaskComment},
    },
    state::ExtAppState,
};

#[derive(TemplateOnce)]
#[template(path = "pages/task_employee.stpl")]
struct TemplateTaskContent {
    page_title: String,
    user_name: String,
    items: Vec<TaskGroup>,
    task_assignees: Vec<EmployeeInfo>,
}

pub async fn handle_employee_tasks(
    user: WebAuthUser,
    Extension(app_state): ExtAppState,
) -> WebResult {
    let db = app_state.db.conn().await?;
    let items = task::get_employee_due_list(&db, user.id).await?;
    let task_assignees = employee::get_list(&db).await?;

    let ctx = TemplateTaskContent {
        page_title: "Task".to_string(),
        user_name: user.name.clone(),
        items,
        task_assignees,
    };
    Ok(Html(ctx.render_once().unwrap()))
}

#[derive(TemplateOnce)]
#[template(path = "pages/task_detail.stpl")]
struct TemplateTaskDetialContent {
    page_title: String,
    user_name: String,
    role_is_admin: bool,
    role_is_manager: bool,
    is_assignee: bool,
    item: Task,
    comments: Vec<TaskComment>,
}
pub async fn handler_detail(
    user: WebAuthUser,
    Extension(app_state): ExtAppState,
    Path(task_id): Path<i64>,
) -> WebResult {
    let db = app_state.db.conn().await?;
    let item = task::get_by_id(&db, task_id).await?;
    let comments = task_comment::get_list(&db, task_id).await?;
    let ctx = TemplateTaskDetialContent {
        page_title: "Task".to_string(),
        user_name: user.name.clone(),
        role_is_admin: user.is_admin(),
        role_is_manager: user.is_manager(),
        is_assignee: user.id == item.assignee_id,
        item,
        comments,
    };
    Ok(Html(ctx.render_once().unwrap()))
}

#[derive(TemplateOnce)]
#[template(path = "pages/all_task.stpl")]
struct TemplateContentTaskAll {
    page_title: String,
    user_name: String,
    role_is_admin: bool,
    role_is_manager: bool,
    items: Vec<TaskAllItem>,
    task_assignees: Vec<EmployeeInfo>,
}

pub async fn handler_search(user: WebAuthUser, Extension(app_state): ExtAppState) -> WebResult {
    let db = app_state.db.conn().await?;

    let input = TaskSearchInput {
        keyword: None,
        assignee_id: None,
        status: Some("O".to_string()),
        priority: None,
    };

    let task_assignees = if user.is_admin() || user.is_qa() || user.is_manager() {
        employee::get_list(&db).await?
    } else {
        vec![]
    };

    let items = all_task::get_list(&db, &input).await?;
    let ctx = TemplateContentTaskAll {
        page_title: "All task".to_string(),
        user_name: user.name.clone(),
        role_is_admin: user.is_admin(),
        role_is_manager: user.is_manager(),
        items,
        task_assignees,
    };

    Ok(Html(ctx.render_once().unwrap()))
}
