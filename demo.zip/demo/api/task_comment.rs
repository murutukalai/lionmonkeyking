// Api - Task Comment

use chrono::{NaiveDate, NaiveDateTime};
use serde::{Deserialize, Serialize};
use tokio_postgres::types::ToSql;

use super::{common::get_display_get, ApiError};
use crate::db::DBConnection;

/* Structs */

#[derive(Debug, Deserialize)]
pub struct TaskCommentCreateInput {
    pub content: String,
}

#[derive(Debug, Deserialize)]
pub struct TaskCommentUpdateInput {
    pub content: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct TaskComment {
    pub id: i64,
    pub created_on: String,
    pub created_by: String,
    pub content: String,
    pub content_html: String,
}

/* Private Functions */

/* Public Functions */

pub async fn create(
    db: &DBConnection<'_>,
    task_id: i64,
    employee_id: i64,
    employee_name: &String,
    input: &TaskCommentCreateInput,
) -> Result<i64, ApiError> {
    let rows = db
        .query(
            "INSERT INTO task_comment(task_id, created_by_id, 
            created_by, content, content_html) VALUES 
            ($1, $2, $3, $4, $5) RETURNING id",
            &[
                &task_id,
                &employee_id,
                &employee_name,
                &input.content,
                &markdown::to_html(&input.content),
            ],
        )
        .await?;

    let Some(row) = rows.first() else {
        return Err(ApiError::Error("Unable to create task_comment".to_string()));
    };

    Ok(row.get(0))
}

pub async fn update_task_comment(
    db: &DBConnection<'_>,
    task_id: i64,
    comment_id: i64,
    input: &TaskCommentUpdateInput,
) -> Result<bool, ApiError> {
    let mut set_clauses: Vec<String> = Vec::new();
    let mut params: Vec<&(dyn ToSql + Sync)> = Vec::new();

    let cont_html: String;
    if let Some(content) = &input.content {
        cont_html = markdown::to_html(content);
        set_clauses.push(format!("content = ${}", params.len() + 1));
        set_clauses.push(format!("content_html = ${}", params.len() + 2));
        params.push(content);
        params.push(&cont_html);
    }

    if set_clauses.is_empty() {
        return Err(ApiError::Error(
            "Enter minimum one data to update".to_string(),
        ));
    }

    let query = format!(
        "UPDATE task_comment SET {} WHERE id = ${} AND task_id = ${}",
        set_clauses.join(", "),
        params.len() + 1,
        params.len() + 2,
    );
    params.push(&comment_id);
    params.push(&task_id);

    let val = db.execute(&query, &params).await?;
    Ok(val != 0)
}

pub async fn get_by_id(
    db: &DBConnection<'_>,
    task_id: i64,
    comment_id: i64,
) -> Result<TaskComment, ApiError> {
    let Some(row) = db
        .query_opt(
            "SELECT * FROM task_comment WHERE id = $1 AND task_id = $2",
            &[&comment_id, &task_id],
        )
        .await?
    else {
        return Err(ApiError::Error(format!(
            "Task Comment with id '{}' does not exist",
            comment_id
        )));
    };

    let comment: TaskComment = TaskComment {
        id: row.get("id"),
        created_on: get_display_get(row.get("created_on")),
        created_by: row.get("created_by"),
        content: row.get("content"),
        content_html: row.get("content_html"),
    };

    Ok(comment)
}

pub async fn get_list(db: &DBConnection<'_>, task_id: i64) -> Result<Vec<TaskComment>, ApiError> {
    let rows = db
        .query(
            "SELECT * FROM task_comment WHERE task_id = $1 ORDER BY id",
            &[&task_id],
        )
        .await?;

    let comments: Vec<TaskComment> = rows
        .iter()
        .map(|row| TaskComment {
            id: row.get("id"),
            created_on: get_display_get(row.get("created_on")),
            created_by: row.get("created_by"),
            content: row.get("content"),
            content_html: row.get("content_html"),
        })
        .collect();

    Ok(comments)
}
