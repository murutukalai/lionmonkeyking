// Api - Common

use chrono::NaiveDateTime;

pub fn get_display_status(status: String) -> String {
    return match status.as_str() {
        "D" => "Draft",
        "R" => "Ready",
        "V" => "Development",
        "C" => "Completed",
        "A" => "Archived",
        _ => "Unknown",
    }
    .to_string();
}

pub fn task_display_status(status: String) -> String {
    match status.as_str() {
        "O" => "Open",
        "I" => "In progress",
        "P" => "Paused",
        "R" => "Resolved",
        "C" => "Closed",
        "V" => "Rejected",
        _ => "Unknown",
    }
    .to_string()
}

pub fn task_priority_display(priority: i16) -> String {
    match priority {
        1 => "Low",
        2 => "Normal",
        3 => "High",
        4 => "Urgent",
        _ => "Unknown",
    }
    .to_string()
}

pub fn get_display_get(value: NaiveDateTime) -> String {
    value.format("%d-%m-%Y").to_string()
}
