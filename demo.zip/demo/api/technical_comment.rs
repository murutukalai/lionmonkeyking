// Api - Technical Comment

use serde::{Deserialize, Serialize};
use tokio_postgres::types::ToSql;

use super::{common::get_display_get, ApiError};
use crate::db::DBConnection;

#[derive(Debug, Deserialize)]
pub struct CommentCreateInput {
    pub technical_type: String,
    pub content: String,
}

#[derive(Debug, Serialize)]
pub struct TechnicalBlockComment {
    pub id: i64,
    pub technical_type: String,
    pub created_by: String,
    pub created_on: String,
    pub content: String,
    pub content_html: String,
}

#[derive(Debug, Deserialize)]
pub struct TechnicalBlockCommentUpdate {
    pub content: Option<String>,
}

pub async fn get_list(
    db: &DBConnection<'_>,
    project_id: i64,
    requirement_id: i64,
    technical_type: &String,
) -> Result<Vec<TechnicalBlockComment>, ApiError> {
    let query = r#"SELECT * FROM technical_block_comment 
        WHERE project_id = $1 AND 
        requirement_id = $2 AND technical_type = $3
        ORDER BY created_on"#
        .to_string();

    let rows = db
        .query(&query, &[&project_id, &requirement_id, &technical_type])
        .await?;

    let technical_vec: Vec<TechnicalBlockComment> = rows
        .iter()
        .map(|row| TechnicalBlockComment {
            id: row.get("id"),
            technical_type: row.get("technical_type"),
            created_by: row.get("created_by"),
            created_on: get_display_get(row.get("created_on")),
            content: row.get("content"),
            content_html: row.get("content_html"),
        })
        .collect();

    Ok(technical_vec)
}

pub async fn get_by_id(
    db: &DBConnection<'_>,
    project_id: i64,
    requirement_id: i64,
    technical_id: i64,
) -> Result<TechnicalBlockComment, ApiError> {
    let row = db
        .query_one(
            "SELECT * FROM 
            technical_block_comment 
            WHERE id = $1 AND 
            project_id = $2 AND 
            requirement_id = $3 
            ORDER BY created_on",
            &[&technical_id, &project_id, &requirement_id],
        )
        .await?;

    // Check whether the id exist
    if row.is_empty() {
        return Err(ApiError::Error(format!(
            "Technical block id {} does not exist ",
            technical_id
        )));
    }

    let technical = TechnicalBlockComment {
        id: row.get("id"),
        technical_type: row.get("type"),
        created_by: row.get("created_by"),
        created_on: get_display_get(row.get("created_on")),
        content: row.get("content"),
        content_html: row.get("content_html"),
    };
    Ok(technical)
}

pub async fn create(
    db: &DBConnection<'_>,
    project_id: i64,
    requirement_id: i64,
    created_by_id: i64,
    created_by: String,
    input: &CommentCreateInput,
) -> Result<i64, ApiError> {
    let rows = db
        .query(
            "INSERT INTO technical_block_comment
            (project_id, requirement_id, technical_type, created_by, created_by_id, content, content_html) 
            VALUES ($1, $2, $3, $4, $5, $6, $7) 
            RETURNING id",
            &[
                &project_id,
                &requirement_id,
                &input.technical_type,
                &created_by,
                &created_by_id,
                &input.content,
                &markdown::to_html(&input.content),
            ],
        )
        .await?;

    let Some(row) = rows.first() else {
        return Err(ApiError::Error(
            "Unable to create new technical_block_comment".to_string(),
        ));
    };

    Ok(row.get(0))
}

pub async fn update_by_id(
    db: &DBConnection<'_>,
    project_id: i64,
    requirement_id: i64,
    technical_id: i64,
    input: &TechnicalBlockCommentUpdate,
) -> Result<bool, ApiError> {
    let mut set_clauses: Vec<String> = Vec::new();
    let mut params: Vec<&(dyn ToSql + Sync)> = Vec::new();

    let cont_html: String;
    if let Some(content) = &input.content {
        cont_html = markdown::to_html(content);
        set_clauses.push(format!("content = ${}", params.len() + 1));
        set_clauses.push(format!("content_html = ${}", params.len() + 2));
        params.push(content);
        params.push(&cont_html);
    }

    if set_clauses.is_empty() {
        return Err(ApiError::Error(
            "Enter minimum one data to update".to_string(),
        ));
    }

    let query = format!(
        "UPDATE technical_block_comment SET {} WHERE id = ${} AND project_id = ${} AND requirement_id = ${}",
        set_clauses.join(", "),
        params.len() + 1,
        params.len() + 2,
        params.len() + 3,
    );
    params.push(&technical_id);
    params.push(&project_id);
    params.push(&requirement_id);

    let val = db.execute(&query, &params).await?;
    Ok(val != 0)
}
