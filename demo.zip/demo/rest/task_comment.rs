// Route - Rest - Task Comment

use axum::{extract::Path, Extension, Json};
use sailfish::TemplateOnce;
use serde::Serialize;
use tracing::error;

use super::{RestAuthUser, RestCommonResponse, RestContentResponse, RestResult};
use crate::{
    api::{
        task,
        task_comment::{self, TaskComment, TaskCommentCreateInput, TaskCommentUpdateInput},
    },
    state::ExtAppState,
};
/* Structs */

#[derive(TemplateOnce)]
#[template(path = "includes/list_task_comment.stpl")]
pub struct TaskContentComment {
    comments: Vec<TaskComment>,
}

#[derive(Serialize, Debug)]
pub struct RestTaskCommentResponse {
    success: bool,
    item: Option<TaskComment>,
    error: Option<String>,
}
/* Private Function */

/* Public function */

pub async fn handler_create(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path(task_id): Path<i64>,
    Json(input): Json<TaskCommentCreateInput>,
) -> RestResult<RestContentResponse> {
    let db = app_state.db.conn().await?;
    let task = task::get_by_id(&db, task_id).await?;
    if !(user.is_admin() || user.is_manager() || (task.assignee_id == user.id)) {
        error!("Unauthorized access");
        return Ok(Json(RestContentResponse {
            success: false,
            error: Some("Unauthorized access".to_string()),
            content: None,
        }));
    }

    let task_comment_create =
        task_comment::create(&db, task_id, user.id, &user.name, &input).await?;

    let mut content: Option<String> = None;
    if task_comment_create > 0 {
        let comments = task_comment::get_list(&db, task_id).await?;
        let ctx = TaskContentComment { comments };
        content = Some(ctx.render_once().unwrap());
    }

    Ok(Json(RestContentResponse {
        success: task_comment_create != 0,
        error: None,
        content,
    }))
}

pub async fn handler_update(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path((task_id, comment_id)): Path<(i64, i64)>,
    Json(input): Json<TaskCommentUpdateInput>,
) -> RestResult<RestCommonResponse> {
    if !user.is_admin() {
        error!("Unauthorized access");
        return Ok(Json(RestCommonResponse {
            success: false,
            error: Some("Unauthorized access".to_string()),
        }));
    }

    let db = app_state.db.conn().await?;
    let success = task_comment::update_task_comment(&db, task_id, comment_id, &input).await?;

    Ok(Json(RestCommonResponse {
        success,
        error: None,
    }))
}

pub async fn handler_get(
    _user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path((task_id, comment_id)): Path<(i64, i64)>,
) -> RestResult<RestTaskCommentResponse> {
    let db = app_state.db.conn().await?;
    let comment = task_comment::get_by_id(&db, task_id, comment_id).await?;

    Ok(Json(RestTaskCommentResponse {
        success: true,
        item: Some(comment),
        error: None,
    }))
}
