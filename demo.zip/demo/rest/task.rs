// Route - Rest - Task

use std::sync::Arc;

use axum::{extract::Path, Extension, Json};
use chrono::NaiveDate;
use sailfish::TemplateOnce;
use serde::{Deserialize, Serialize};
use tracing::error;

use super::{RestAuthUser, RestContentResponse, RestError, RestResult};
use crate::{
    api::{
        all_task::{self, TaskAllItem, TaskSearchInput},
        employee::{self, EmployeeInfo},
        project, requirement,
        task::{self, get_status_by_id, Task, TaskCreateOptions, TaskStatusInfo},
        task_comment::{self, TaskComment},
    },
    route::rest::RestCommonResponse,
    state::{AppState, ExtAppState},
};

/* Structs */

#[derive(Serialize, Debug)]
pub struct RestTaskResponse {
    success: bool,
    item: Option<Task>,
    error: Option<String>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct TaskCreateInput {
    pub title: String,
    pub priority: String,
    pub assignee_id: String,
    pub due_date: String,
    pub description: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct TaskUpdateInput {
    pub title: Option<String>,
    pub description: Option<String>,
    pub assignee_id: Option<String>,
    pub priority: Option<String>,
    pub due_date: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct RestTaskAllSearchInput {
    keyword: Option<String>,
    assignee_id: Option<String>,
    status: Option<String>,
    priority: Option<String>,
}

#[derive(TemplateOnce)]
#[template(path = "includes/list_all_task.stpl")]
struct TemplateContentTaskAll {
    role_is_admin: bool,
    role_is_manager: bool,
    items: Vec<TaskAllItem>,
    task_assignees: Vec<EmployeeInfo>,
}

pub async fn handler_search(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Json(input): Json<RestTaskAllSearchInput>,
) -> RestResult<RestContentResponse> {
    let db = app_state.db.conn().await?;

    let mut assignee_id: Option<i64> = None;
    if let Some(input_assignee_id) = input.assignee_id {
        if let Ok(id) = input_assignee_id.parse::<i64>() {
            assignee_id = Some(id);
        } else {
            assignee_id = None
        }
    }

    let mut priority: Option<i16> = None;
    if let Some(input_priority) = input.priority {
        if let Ok(int_priority) = input_priority.parse::<i16>() {
            priority = Some(int_priority);
        } else {
            priority = None
        }
    }

    let api_input = all_task::TaskSearchInput {
        keyword: input.keyword,
        assignee_id,
        status: input.status,
        priority,
    };

    let task_assignees = if user.is_admin() || user.is_qa() || user.is_manager() {
        employee::get_list(&db).await?
    } else {
        vec![]
    };

    let items = all_task::get_list(&db, &api_input).await?;
    let ctx = TemplateContentTaskAll {
        role_is_admin: user.is_admin(),
        role_is_manager: user.is_manager(),
        items,
        task_assignees,
    };

    let content = Some(ctx.render_once().unwrap());
    Ok(Json(RestContentResponse {
        success: true,
        error: None,
        content,
    }))
}

pub async fn handler_get(
    _user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path(task_id): Path<i64>,
) -> RestResult<RestTaskResponse> {
    let db = app_state.db.conn().await?;
    let item = task::get_by_id(&db, task_id).await?;

    Ok(Json(RestTaskResponse {
        success: true,
        item: Some(item),
        error: None,
    }))
}

pub async fn handle_create(
    user: RestAuthUser,
    app_state: &Arc<AppState>,
    slug: &String,
    req_id: Option<i64>,
    task_type: &str,
    input: TaskCreateInput,
) -> RestResult<RestCommonResponse> {
    let Ok(due_date) = NaiveDate::parse_from_str(input.due_date.as_str(), "%Y-%m-%d") else {
        return Err(RestError::Error(
            "Unable to convert string to date".to_string(),
        ));
    };

    let Ok(assignee_id) = input.assignee_id.parse::<i64>() else {
        return Err(RestError::Error(
            "Unable to convert string to assignee id".to_string(),
        ));
    };

    let Ok(priority) = input.priority.parse::<i16>() else {
        return Err(RestError::Error(
            "Unable to convert string to priority".to_string(),
        ));
    };

    let api_input = task::TaskCreateInput {
        title: input.title,
        priority,
        assignee_id,
        due_date,
        description: input.description,
    };

    let db = app_state.db.conn().await?;
    let project = project::get_by_slug(&db, slug).await?;
    let mut technical_type: Option<String> = None;
    if req_id.is_some() {
        let assignee_team = employee::get_team(&db, assignee_id).await?;
        if let Some(team) = assignee_team {
            if team.team_type != *"qa" {
                technical_type = Some(team.team_type)
            }
        }
    }

    let val = task::create(
        &db,
        project.id,
        req_id,
        &TaskCreateOptions {
            created_by: user.name.clone(),
            created_by_id: user.id,
            technical_type,
            task_type: task_type.to_string(),
        },
        &api_input,
    )
    .await?;

    Ok(Json(RestCommonResponse {
        success: val != 0,
        error: None,
    }))
}

pub async fn handle_create_by_project(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path(slug): Path<String>,
    Json(input): Json<TaskCreateInput>,
) -> RestResult<RestCommonResponse> {
    if !(user.is_admin() || user.is_manager() || user.is_qa()) {
        error!("Unauthorized access");
        return Ok(Json(RestCommonResponse {
            success: false,
            error: Some("Unauthorized access".to_string()),
        }));
    }

    let return_result = handle_create(user, &app_state, &slug, None, "T", input).await?;
    Ok(return_result)
}

pub async fn handler_create_by_req(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path((slug, req_id)): Path<(String, i64)>,
    Json(input): Json<TaskCreateInput>,
) -> RestResult<RestCommonResponse> {
    if !(user.is_admin() || user.is_manager() || user.is_qa()) {
        error!("Unauthorized access");
        return Ok(Json(RestCommonResponse {
            success: false,
            error: Some("Unauthorized access".to_string()),
        }));
    }

    let return_result = handle_create(user, &app_state, &slug, Some(req_id), "T", input).await?;
    Ok(return_result)
}

pub async fn handler_bug_create(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path((slug, req_id)): Path<(String, i64)>,
    Json(input): Json<TaskCreateInput>,
) -> RestResult<RestCommonResponse> {
    let db = app_state.db.conn().await?;
    let project = project::get_by_slug(&db, &slug).await?;
    let requirement = requirement::get_by_id(&db, project.id, req_id).await?;

    let mut user_is_qa = false;
    if requirement.qa_assignee_id == Some(user.id) {
        user_is_qa = true
    }

    if !(user.is_admin() || user.is_qa() || user.is_manager() || user_is_qa) {
        error!("Unauthorized access");
        return Ok(Json(RestCommonResponse {
            success: false,
            error: Some("Unauthorized access".to_string()),
        }));
    }

    let return_result = handle_create(user, &app_state, &slug, Some(req_id), "B", input).await?;
    Ok(return_result)
}

pub async fn handler_update(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path(id): Path<i64>,
    Json(input): Json<TaskUpdateInput>,
) -> RestResult<RestContentResponse> {
    if !(user.is_admin() || user.is_manager()) {
        error!("Unauthorized access");
        return Ok(Json(RestContentResponse {
            success: false,
            error: Some("Unauthorized access".to_string()),
            content: None,
        }));
    }

    let mut due_date: Option<NaiveDate> = None;
    if let Some(input_due_date) = input.due_date {
        let Ok(date) = NaiveDate::parse_from_str(input_due_date.as_str(), "%Y-%m-%d") else {
            return Err(RestError::Error(
                "Unable to convert string to date".to_string(),
            ));
        };
        due_date = Some(date);
    }
    let mut assignee_id: Option<i64> = None;
    if let Some(input_assignee_id) = input.assignee_id {
        let Ok(id) = input_assignee_id.parse::<i64>() else {
            return Err(RestError::Error(
                "Unable to convert string to assignee id".to_string(),
            ));
        };
        assignee_id = Some(id);
    }

    let mut priority: Option<i16> = None;
    if let Some(input_priority) = input.priority {
        let Ok(int_priority) = input_priority.parse::<i16>() else {
            return Err(RestError::Error(
                "Unable to convert string to priority".to_string(),
            ));
        };
        priority = Some(int_priority)
    }

    let api_input = task::TaskUpdateInput {
        title: input.title,
        description: input.description,
        assignee_id,
        priority,
        due_date,
    };

    let db = app_state.db.conn().await?;
    let success = task::update_by_id(&db, id, api_input).await?;

    if success {
        let task_assignees = if user.is_admin() || user.is_qa() || user.is_manager() {
            employee::get_list(&db).await?
        } else {
            vec![]
        };

        let input = TaskSearchInput {
            keyword: None,
            assignee_id: None,
            status: Some("O".to_string()),
            priority: None,
        };

        let items = all_task::get_list(&db, &input).await?;
        let ctx = TemplateContentTaskAll {
            role_is_admin: user.is_admin(),
            role_is_manager: user.is_manager(),
            items,
            task_assignees,
        };

        let content = Some(ctx.render_once().unwrap());
        return Ok(Json(RestContentResponse {
            success: true,
            error: None,
            content,
        }));
    }

    Ok(Json(RestContentResponse {
        success,
        error: None,
        content: None,
    }))
}

#[derive(TemplateOnce)]
#[template(path = "includes/task_button.stpl")]
struct TemplateDetailTask {
    item: TaskStatusInfo,
}

/*
pub async fn handler_details(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path(id): Path<i64>,
) -> RestResult<RestContentResponse> {
    let db = app_state.db.conn().await?;
    let item = task::get_by_id(&db, id).await?;
    let ctx = TemplateDetailTask {
        role_is_admin: user.is_admin(),
        item,
    };
    let content = Some(ctx.render_once().unwrap());

    Ok(Json(RestContentResponse {
        success: true,
        error: None,
        content,
    }))
}
*/

#[derive(Debug, Deserialize)]
pub struct RestTaskStatusUpdateInput {
    status: String,
}

pub async fn handler_status_update(
    user: RestAuthUser,
    Extension(app_state): ExtAppState,
    Path(task_id): Path<i64>,
    Json(input): Json<RestTaskStatusUpdateInput>,
) -> RestResult<RestContentResponse> {
    let db = app_state.db.conn().await?;
    let success = task::update_status(&db, task_id, input.status).await?;
    if success {
        let item = get_status_by_id(&db, task_id).await?;
        let ctx = TemplateDetailTask {
            item
        };
        let content = Some(ctx.render_once().unwrap());

        return Ok(Json(RestContentResponse {
            success: true,
            error: None,
            content,
        }));
    }
    Ok(Json(RestContentResponse {
        success: false,
        error: None,
        content: None,
    }))
}
